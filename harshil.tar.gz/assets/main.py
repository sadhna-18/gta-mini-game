import pygame
import math
import random
import asyncio

pygame.init()

# ---------- Window Setup ----------
W, H = 900, 600
win = pygame.display.set_mode((W, H))
pygame.display.set_caption("GTA Mini - 2D Top Down")
clock = pygame.time.Clock()
font = pygame.font.SysFont('Arial', 20)
big_font = pygame.font.SysFont('Arial', 48, bold=True)

# ---------- Colors ----------
BG_COLOR = (58, 122, 58)
ROAD_COLOR = (65, 65, 70)
LINE_COLOR = (230, 200, 40)
CAR_COLOR = (200, 30, 30)
CAR_DARK = (140, 15, 15)
PLAYER_COLOR = (30, 120, 220)
PLAYER_DARK = (15, 70, 150)
BULLET_COLOR = (255, 220, 50)
TEXT_COLOR = (255, 255, 255)
BUILDING_COLOR = (100, 90, 85)
BUILDING_ROOF = (75, 68, 64)
ENEMY_COLOR = (200, 60, 160)
ENEMY_DARK = (140, 30, 110)
SHADOW_COLOR = (0, 0, 0, 60)
HUD_BG = (0, 0, 0, 120)

# ---------- Player ----------
player = pygame.Rect(W // 2, H // 2, 20, 20)
player_speed = 4
in_car = False
player_health = 100

# ---------- Car ----------
car_pos = [400, 300]
car_angle = 0.0
car_speed = 0.0
MAX_SPEED = 6
ACCEL = 0.2
FRICTION = 0.05
car_rect_size = (46, 26)

# ---------- Bullets ----------
bullets = []
BULLET_SPEED = 12

# ---------- Score ----------
score = 0
game_over = False

# ---------- Roads ----------
roads = [
    pygame.Rect(0, 280, W, 80),
    pygame.Rect(400, 0, 80, H),
]

# ---------- Buildings (obstacles with collision) ----------
buildings = [
    pygame.Rect(40, 40, 140, 100),
    pygame.Rect(220, 60, 120, 80),
    pygame.Rect(600, 40, 160, 120),
    pygame.Rect(780, 100, 100, 140),
    pygame.Rect(40, 420, 150, 120),
    pygame.Rect(230, 400, 110, 90),
    pygame.Rect(600, 420, 150, 130),
    pygame.Rect(760, 380, 120, 80),
]


def rects_collide_point(x, y, size, rect_list):
    """Check if a point (with small buffer) collides with any rect in the list."""
    test_rect = pygame.Rect(x - size / 2, y - size / 2, size, size)
    for r in rect_list:
        if test_rect.colliderect(r):
            return True
    return False


# ---------- Enemies ----------
class Enemy:
    def __init__(self):
        self.respawn()
        self.hp = 2

    def respawn(self):
        while True:
            x = random.randint(30, W - 30)
            y = random.randint(30, H - 30)
            if not rects_collide_point(x, y, 24, buildings):
                self.pos = [x, y]
                break
        self.hp = 2
        self.alive = True
        self.speed = random.uniform(0.8, 1.6)

    def update(self, target_pos):
        if not self.alive:
            return
        dx = target_pos[0] - self.pos[0]
        dy = target_pos[1] - self.pos[1]
        dist = math.hypot(dx, dy)
        if dist > 1:
            nx, ny = self.pos[0] + (dx / dist) * self.speed, self.pos[1] + (dy / dist) * self.speed
            if not rects_collide_point(nx, self.pos[1], 20, buildings):
                self.pos[0] = nx
            if not rects_collide_point(self.pos[0], ny, 20, buildings):
                self.pos[1] = ny

    def draw(self):
        pygame.draw.ellipse(win, (0, 0, 0, 60), (self.pos[0] - 12, self.pos[1] + 6, 24, 10))
        pygame.draw.circle(win, ENEMY_DARK, (int(self.pos[0]), int(self.pos[1]) + 2), 12)
        pygame.draw.circle(win, ENEMY_COLOR, (int(self.pos[0]), int(self.pos[1])), 12)
        pygame.draw.circle(win, (255, 255, 255), (int(self.pos[0]), int(self.pos[1])), 12, 2)


enemies = [Enemy() for _ in range(5)]


# ---------- Touch Controls (for mobile) ----------
BTN = 55
dpad_cx, dpad_cy = 95, H - 95
btn_up = pygame.Rect(dpad_cx - BTN // 2, dpad_cy - int(BTN * 1.1), BTN, BTN)
btn_down = pygame.Rect(dpad_cx - BTN // 2, dpad_cy + int(BTN * 0.1), BTN, BTN)
btn_left = pygame.Rect(dpad_cx - int(BTN * 1.6), dpad_cy - BTN // 2, BTN, BTN)
btn_right = pygame.Rect(dpad_cx + int(BTN * 0.6), dpad_cy - BTN // 2, BTN, BTN)

btn_shoot = pygame.Rect(W - 85, H - 155, 65, 65)
btn_enter = pygame.Rect(W - 165, H - 95, 65, 65)

touch_state = {"up": False, "down": False, "left": False, "right": False}
facing = [0.0, -1.0]  # last facing direction for touch-shoot button


def point_in_circle_btn(rect, x, y):
    return math.hypot(x - rect.centerx, y - rect.centery) <= rect.width / 2


def update_touch_state():
    touch_state["up"] = touch_state["down"] = touch_state["left"] = touch_state["right"] = False
    if pygame.mouse.get_pressed()[0]:
        mx, my = pygame.mouse.get_pos()
        if point_in_circle_btn(btn_up, mx, my):
            touch_state["up"] = True
        if point_in_circle_btn(btn_down, mx, my):
            touch_state["down"] = True
        if point_in_circle_btn(btn_left, mx, my):
            touch_state["left"] = True
        if point_in_circle_btn(btn_right, mx, my):
            touch_state["right"] = True


def draw_touch_controls():
    def draw_btn(rect, label):
        s = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        pygame.draw.circle(s, (255, 255, 255, 70), (rect.width // 2, rect.height // 2), rect.width // 2)
        pygame.draw.circle(s, (255, 255, 255, 160), (rect.width // 2, rect.height // 2), rect.width // 2, 3)
        win.blit(s, rect.topleft)
        txt = font.render(label, True, (255, 255, 255))
        win.blit(txt, txt.get_rect(center=rect.center))

    draw_btn(btn_up, "^")
    draw_btn(btn_down, "v")
    draw_btn(btn_left, "<")
    draw_btn(btn_right, ">")
    draw_btn(btn_enter, "E")
    draw_btn(btn_shoot, "*")



    for r in roads:
        pygame.draw.rect(win, ROAD_COLOR, r)
    for x in range(0, W, 40):
        pygame.draw.rect(win, LINE_COLOR, (x, 315, 20, 5))
    for y in range(0, H, 40):
        pygame.draw.rect(win, LINE_COLOR, (435, y, 5, 20))


def draw_buildings():
    for b in buildings:
        shadow = pygame.Rect(b.x + 6, b.y + 6, b.width, b.height)
        pygame.draw.rect(win, (30, 30, 30), shadow, border_radius=4)
        pygame.draw.rect(win, BUILDING_COLOR, b, border_radius=4)
        roof = pygame.Rect(b.x + 6, b.y + 6, b.width - 12, b.height - 12)
        pygame.draw.rect(win, BUILDING_ROOF, roof, border_radius=3)
        # windows
        for wx in range(b.x + 12, b.x + b.width - 10, 22):
            for wy in range(b.y + 12, b.y + b.height - 10, 22):
                pygame.draw.rect(win, (210, 220, 120), (wx, wy, 10, 10))


def draw_car():
    car_surf = pygame.Surface(car_rect_size, pygame.SRCALPHA)
    pygame.draw.rect(car_surf, CAR_DARK, (0, 3, *car_rect_size), border_radius=8)
    pygame.draw.rect(car_surf, CAR_COLOR, (0, 0, car_rect_size[0], car_rect_size[1] - 3), border_radius=8)
    pygame.draw.rect(car_surf, (40, 40, 60), (car_rect_size[0] - 16, 4, 12, car_rect_size[1] - 11), border_radius=2)
    pygame.draw.circle(car_surf, (255, 240, 150), (car_rect_size[0] - 3, 4), 3)
    pygame.draw.circle(car_surf, (255, 240, 150), (car_rect_size[0] - 3, car_rect_size[1] - 7), 3)
    rotated = pygame.transform.rotate(car_surf, -car_angle)
    rect = rotated.get_rect(center=car_pos)
    win.blit(rotated, rect.topleft)


def draw_player():
    pygame.draw.ellipse(win, (0, 0, 0, 60), (player.centerx - 12, player.centery + 6, 24, 10))
    pygame.draw.circle(win, PLAYER_DARK, (player.centerx, player.centery + 2), 13)
    pygame.draw.circle(win, PLAYER_COLOR, player.center, 13)
    pygame.draw.circle(win, (255, 255, 255), player.center, 13, 2)


def is_near_car():
    dist = math.hypot(player.centerx - car_pos[0], player.centery - car_pos[1])
    return dist < 45


def draw_hud():
    hud_surf = pygame.Surface((W, 55), pygame.SRCALPHA)
    hud_surf.fill((0, 0, 0, 110))
    win.blit(hud_surf, (0, 0))

    line1 = "WASD/Arrows: Move   E: Enter-Exit Car   Click/*: Shoot   ESC: Quit"
    line2 = f"Status: {'Driving' if in_car else 'On Foot'}   Speed: {abs(car_speed):.1f}   Score: {score}   HP: {player_health}"
    win.blit(font.render(line1, True, TEXT_COLOR), (10, 8))
    win.blit(font.render(line2, True, (255, 230, 120)), (10, 30))


def draw_game_over():
    overlay = pygame.Surface((W, H), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 170))
    win.blit(overlay, (0, 0))
    text = big_font.render("GAME OVER", True, (255, 80, 80))
    win.blit(text, text.get_rect(center=(W // 2, H // 2 - 30)))
    sub = font.render(f"Final Score: {score}   Press R to Restart", True, TEXT_COLOR)
    win.blit(sub, sub.get_rect(center=(W // 2, H // 2 + 30)))


def reset_game():
    global player, in_car, car_pos, car_angle, car_speed, bullets, score, player_health, game_over, enemies
    player = pygame.Rect(W // 2, H // 2, 20, 20)
    in_car = False
    car_pos = [400, 300]
    car_angle = 0.0
    car_speed = 0.0
    bullets = []
    score = 0
    player_health = 100
    game_over = False
    enemies = [Enemy() for _ in range(5)]


async def main():
    global in_car, car_speed, car_angle, player, score, player_health, game_over

    running = True
    while running:
        clock.tick(60)
        win.fill(BG_COLOR)
        draw_roads()
        draw_buildings()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                if event.key == pygame.K_r and game_over:
                    reset_game()
                if not game_over and event.key == pygame.K_e:
                    if not in_car and is_near_car():
                        in_car = True
                    elif in_car:
                        in_car = False
                        player.centerx = int(car_pos[0] + 40)
                        player.centery = int(car_pos[1])

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not game_over:
                mx, my = pygame.mouse.get_pos()

                if point_in_circle_btn(btn_enter, mx, my):
                    if not in_car and is_near_car():
                        in_car = True
                    elif in_car:
                        in_car = False
                        player.centerx = int(car_pos[0] + 40)
                        player.centery = int(car_pos[1])
                elif point_in_circle_btn(btn_shoot, mx, my):
                    if not in_car:
                        bullets.append([player.centerx, player.centery, facing[0], facing[1]])
                elif not (btn_up.collidepoint(mx, my) or btn_down.collidepoint(mx, my)
                          or btn_left.collidepoint(mx, my) or btn_right.collidepoint(mx, my)):
                    if not in_car:
                        dx, dy = mx - player.centerx, my - player.centery
                        dist = math.hypot(dx, dy)
                        if dist != 0:
                            vx, vy = dx / dist, dy / dist
                            facing[0], facing[1] = vx, vy
                            bullets.append([player.centerx, player.centery, vx, vy])

        if not game_over:
            update_touch_state()
            keys = pygame.key.get_pressed()
            k_up = keys[pygame.K_w] or touch_state["up"]
            k_down = keys[pygame.K_s] or touch_state["down"]
            k_left = keys[pygame.K_a] or touch_state["left"]
            k_right = keys[pygame.K_d] or touch_state["right"]

            if in_car:
                if k_up:
                    car_speed = min(car_speed + ACCEL, MAX_SPEED)
                elif k_down:
                    car_speed = max(car_speed - ACCEL, -MAX_SPEED / 2)
                else:
                    if car_speed > 0:
                        car_speed = max(car_speed - FRICTION, 0)
                    elif car_speed < 0:
                        car_speed = min(car_speed + FRICTION, 0)

                if k_left:
                    car_angle -= 3 * (car_speed / MAX_SPEED if car_speed != 0 else 0.5)
                if k_right:
                    car_angle += 3 * (car_speed / MAX_SPEED if car_speed != 0 else 0.5)

                rad = math.radians(car_angle)
                new_x = car_pos[0] + math.cos(rad) * car_speed
                new_y = car_pos[1] + math.sin(rad) * car_speed
                new_x = max(20, min(W - 20, new_x))
                new_y = max(20, min(H - 20, new_y))

                if not rects_collide_point(new_x, car_pos[1], 40, buildings):
                    car_pos[0] = new_x
                else:
                    car_speed *= -0.3
                if not rects_collide_point(car_pos[0], new_y, 24, buildings):
                    car_pos[1] = new_y
                else:
                    car_speed *= -0.3
            else:
                dx = dy = 0
                if k_up:
                    dy -= player_speed
                if k_down:
                    dy += player_speed
                if k_left:
                    dx -= player_speed
                if k_right:
                    dx += player_speed

                if dx != 0 or dy != 0:
                    fdist = math.hypot(dx, dy)
                    facing[0], facing[1] = dx / fdist, dy / fdist

                new_x = max(0, min(W - player.width, player.x + dx))
                new_y = max(0, min(H - player.height, player.y + dy))

                if not rects_collide_point(new_x + 10, player.centery, 20, buildings):
                    player.x = new_x
                if not rects_collide_point(player.centerx, new_y + 10, 20, buildings):
                    player.y = new_y

            # Update bullets
            for b in bullets[:]:
                b[0] += b[2] * BULLET_SPEED
                b[1] += b[3] * BULLET_SPEED
                if b[0] < 0 or b[0] > W or b[1] < 0 or b[1] > H:
                    bullets.remove(b)
                    continue
                if rects_collide_point(b[0], b[1], 6, buildings):
                    bullets.remove(b)
                    continue
                for e in enemies:
                    if e.alive and math.hypot(b[0] - e.pos[0], b[1] - e.pos[1]) < 14:
                        e.hp -= 1
                        if b in bullets:
                            bullets.remove(b)
                        if e.hp <= 0:
                            e.alive = False
                            score += 10
                        break

            # Update enemies
            target = car_pos if in_car else player.center
            for e in enemies:
                if e.alive:
                    e.update(target)
                    dist_to_target = math.hypot(e.pos[0] - target[0], e.pos[1] - target[1])
                    if dist_to_target < 18:
                        player_health -= 1
                        if player_health <= 0:
                            player_health = 0
                            game_over = True
                else:
                    if random.random() < 0.003:
                        e.respawn()

        # Draw everything
        draw_car()
        for b in bullets:
            pygame.draw.circle(win, BULLET_COLOR, (int(b[0]), int(b[1])), 4)

        for e in enemies:
            if e.alive:
                e.draw()

        if not in_car:
            draw_player()

        draw_hud()
        draw_touch_controls()

        if game_over:
            draw_game_over()

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())