import pygame
import math
import random
import asyncio

pygame.init()

# ---------- Window Setup ----------
W, H = 900, 600
win = pygame.display.set_mode((W, H))
pygame.display.set_caption("GTA Mini - 2D Top Down")
clock = pygame.time.Clock()
font = pygame.font.SysFont('Arial', 20)

# ---------- Colors ----------
BG_COLOR = (60, 130, 60)      # grass
ROAD_COLOR = (70, 70, 70)
LINE_COLOR = (230, 230, 0)
CAR_COLOR = (200, 30, 30)
PLAYER_COLOR = (30, 120, 220)
BULLET_COLOR = (255, 255, 0)
TEXT_COLOR = (255, 255, 255)

# ---------- Player ----------
player = pygame.Rect(W // 2, H // 2, 20, 20)
player_speed = 4
in_car = False

# ---------- Car ----------
car_pos = [400, 300]
car_angle = 0
car_speed = 0
MAX_SPEED = 6
ACCEL = 0.2
FRICTION = 0.05
car_rect_size = (50, 30)

# ---------- Bullets ----------
bullets = []
BULLET_SPEED = 12

# ---------- Roads (simple static layout) ----------
roads = [
    pygame.Rect(0, 280, W, 80),      # horizontal road
    pygame.Rect(400, 0, 80, H),      # vertical road
]


def draw_roads():
    for r in roads:
        pygame.draw.rect(win, ROAD_COLOR, r)
    # dashed lines
    for x in range(0, W, 40):
        pygame.draw.rect(win, LINE_COLOR, (x, 315, 20, 5))
    for y in range(0, H, 40):
        pygame.draw.rect(win, LINE_COLOR, (435, y, 5, 20))


def draw_car():
    car_surf = pygame.Surface(car_rect_size, pygame.SRCALPHA)
    pygame.draw.rect(car_surf, CAR_COLOR, (0, 0, *car_rect_size), border_radius=6)
    pygame.draw.rect(car_surf, (0, 0, 0), (car_rect_size[0] - 10, 5, 8, car_rect_size[1] - 10))
    rotated = pygame.transform.rotate(car_surf, -car_angle)
    rect = rotated.get_rect(center=car_pos)
    win.blit(rotated, rect.topleft)


def draw_player():
    pygame.draw.circle(win, PLAYER_COLOR, player.center, 12)


def is_near_car():
    dist = math.hypot(player.centerx - car_pos[0], player.centery - car_pos[1])
    return dist < 40


async def main():
    global in_car, car_speed, car_angle, player

    running = True
    while running:
        clock.tick(60)
        win.fill(BG_COLOR)
        draw_roads()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                if event.key == pygame.K_e:
                    if not in_car and is_near_car():
                        in_car = True
                    elif in_car:
                        in_car = False
                        player.centerx = car_pos[0] + 40
                        player.centery = car_pos[1]

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if not in_car:
                    mx, my = pygame.mouse.get_pos()
                    dx, dy = mx - player.centerx, my - player.centery
                    dist = math.hypot(dx, dy)
                    if dist != 0:
                        vx, vy = dx / dist, dy / dist
                        bullets.append([player.centerx, player.centery, vx, vy])

        keys = pygame.key.get_pressed()

        if in_car:
            # Car controls
            if keys[pygame.K_w]:
                car_speed = min(car_speed + ACCEL, MAX_SPEED)
            elif keys[pygame.K_s]:
                car_speed = max(car_speed - ACCEL, -MAX_SPEED / 2)
            else:
                if car_speed > 0:
                    car_speed = max(car_speed - FRICTION, 0)
                elif car_speed < 0:
                    car_speed = min(car_speed + FRICTION, 0)

            if keys[pygame.K_a]:
                car_angle -= 3 * (car_speed / MAX_SPEED if car_speed != 0 else 0.5)
            if keys[pygame.K_d]:
                car_angle += 3 * (car_speed / MAX_SPEED if car_speed != 0 else 0.5)

            rad = math.radians(car_angle)
            car_pos[0] += math.cos(rad) * car_speed
            car_pos[1] += math.sin(rad) * car_speed

            car_pos[0] = max(20, min(W - 20, car_pos[0]))
            car_pos[1] = max(20, min(H - 20, car_pos[1]))
        else:
            # Player on-foot controls
            if keys[pygame.K_w]:
                player.y -= player_speed
            if keys[pygame.K_s]:
                player.y += player_speed
            if keys[pygame.K_a]:
                player.x -= player_speed
            if keys[pygame.K_d]:
                player.x += player_speed

            player.x = max(0, min(W - player.width, player.x))
            player.y = max(0, min(H - player.height, player.y))

        # Update bullets
        for b in bullets[:]:
            b[0] += b[2] * BULLET_SPEED
            b[1] += b[3] * BULLET_SPEED
            if b[0] < 0 or b[0] > W or b[1] < 0 or b[1] > H:
                bullets.remove(b)

        # Draw everything
        draw_car()
        for b in bullets:
            pygame.draw.circle(win, BULLET_COLOR, (int(b[0]), int(b[1])), 4)

        if not in_car:
            draw_player()

        # HUD
        hud_lines = [
            "WASD: Move / Drive   E: Enter-Exit Car   Mouse Click: Shoot",
            f"Status: {'Driving' if in_car else 'On Foot'}   Speed: {car_speed:.1f}",
        ]
        for i, line in enumerate(hud_lines):
            text = font.render(line, True, TEXT_COLOR)
            win.blit(text, (10, 10 + i * 22))

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())